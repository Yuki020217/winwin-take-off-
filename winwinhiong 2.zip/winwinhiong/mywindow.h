#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include "tower.h"
#include <QList>
#include "myobject.h"
class MyWindow : public QMainWindow
{
    Q_OBJECT
public:
    void paintEvent(QPaintEvent *);
    explicit MyWindow(QWidget *parent = nullptr);
    void set_tower1();
    void set_tower2();
    void set_tower3();
    void addMyObject();
    void updateScene();
private:
    QList<Tower *> tower_list;
    QList<MyObject*> object_list;
signals:
    void chooseBack();
public slots:
};

#endif // MYWINDOW_H

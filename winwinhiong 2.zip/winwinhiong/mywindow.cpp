#include "mywindow.h"
#include "mybutton.h"
#include <QPainter>
#include <QPixmap>
#include <QTimer>


MyWindow::MyWindow(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(600,800);
    MyButton * start_btn = new MyButton(":/pics/start.png");
    start_btn->setParent(this);
    start_btn->move(0,0);
    connect(start_btn,&MyButton::clicked,this,&MyWindow::addMyObject);
    MyButton * stop_btn = new MyButton(":/pics/stop.png");
    stop_btn->setParent(this);
    stop_btn->move(0,40);
    MyButton * reset_btn = new MyButton(":/pics/reset.png");
    reset_btn->setParent(this);
    reset_btn->move(0,80);
    MyButton * back_btn = new MyButton(":/pics/back.png");
    back_btn->setParent(this);
    back_btn->move(0,120);
    MyButton * setTower1= new MyButton(":/character/crywin.png");
    setTower1->setParent(this);
    setTower1->move(455,685);
    connect(setTower1,&MyButton::clicked,this,&MyWindow::set_tower1);
    MyButton * setTower2= new MyButton(":/character/tikwin.png");
    setTower2->setParent(this);
    setTower2->move(428,575);
    connect(setTower2,&MyButton::clicked,this,&MyWindow::set_tower2);
    MyButton * setTower3= new MyButton(":/character/babywin.png");
    setTower3->setParent(this);
    setTower3->move(410,475);
    connect(setTower3,&MyButton::clicked,this,&MyWindow::set_tower3);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });
    QTimer * timer = new QTimer (this);
    connect(timer,&QTimer::timeout,this,&MyWindow::updateScene);
            timer->start(10);
}

void MyWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/pics/background.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    foreach(Tower * tower,tower_list)
        tower->draw(&painter);
    foreach (MyObject * object,object_list)
        object->draw(&painter);
}
void MyWindow::set_tower1(){
    Tower * a_new_tower = new Tower(QPoint(220,410),":/character/smilewin.png");
    tower_list.push_back(a_new_tower);
    update();
}
void MyWindow::set_tower2(){
    Tower * a_new_tower = new Tower(QPoint(200,300),":/character/tokwin.png");
    tower_list.push_back(a_new_tower);
    update();
}
void MyWindow::set_tower3(){
    Tower * a_new_tower = new Tower(QPoint(200,200),":/character/motorwin.png");
    tower_list.push_back(a_new_tower);
    update();
}
void MyWindow::addMyObject(){
    MyObject * object = new MyObject(QPoint(100,0),QPoint(100,800),":/object/cherrybomb.png");
    object_list.push_back(object);
    object->move();
    update();
}
void MyWindow::updateScene(){
    update();
}

#include "tower.h"
#include "mywindow.h"
#include "utility.h"
#include "bullet.h"
#include "enemy.h"


#include <QPoint>
#include <QPainter>
#include <QString>
#include <QSize>


const QSize Tower::myFixedSize(10,10);

Tower::Tower()
{

}

Tower::~Tower()
{
    delete myFireRateTime;
    myFireRateTime=NULL;
    myChooseEnemy=NULL;
    myGame=NULL;
    delete myChooseEnemy;
}

Tower::Tower(QPoint pos,MyWindow * game,const QPixmap & sprite):

    myPos(pos),
    mySprite(sprite),
    myAttackRange(75),
    myGame(game),
    myAttacking(false),
    myDamage(10),//攻击力10
    myFireRate(1000),//1000ms
    myChooseEnemy(NULL)

{
    myFireRateTime=new QTimer(this);
    connect(myFireRateTime,SIGNAL(timeout()),this,SLOT(shootWeapon()));

}

void Tower::draw(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::green);
    painter->drawEllipse(myPos,myAttackRange,myAttackRange);

    painter->drawPixmap(myPos.x()-myFixedSize.width()/2,myPos.y()-myFixedSize.height()/2-10,mySprite);
}
void Tower::chooseEnemyFromAttack(Enemy *enemy)
{
    myChooseEnemy=enemy;
    attackEnemy();
    myChooseEnemy->getAttacked(this);//该敌人受到该防御塔的攻击
}

void Tower::attackEnemy()
{
    myFireRateTime->start(myFireRate);//开始攻击
}

void Tower::shootWeapon()
{
    Bullet * bullet=new Bullet(myPos,myChooseEnemy->getPos(),myDamage,myChooseEnemy,myGame);//构造一个子弹，准备攻击敌人
    bullet->move();
    myGame->addBullet(bullet);//将该子弹添加到mainwindow中
}
void Tower::targetKilled()
{
    if(myChooseEnemy)
    {
        myChooseEnemy=NULL;
    }
    myFireRateTime->stop();//敌人死亡，停止开火
}

void Tower::lostSightOfEnemy()
{
    myChooseEnemy->getLostSight(this);
    if(myChooseEnemy)
    {
        myChooseEnemy=NULL;
    }
    myFireRateTime->stop();
}
void Tower::checkEnemyInRange()
{
    if(myChooseEnemy)//如果有了攻击的敌人
        {
            QVector2D normalized(myChooseEnemy->getPos()-myPos);
            normalized.normalize();
            if(!collisionWithCircle(myPos,myAttackRange,myChooseEnemy->getPos(),1))//当敌人不在范围内的时候
            {
                lostSightOfEnemy();
            }
        }
        else//如果没有攻击的敌人，就遍历enemy_list，找到在攻击范围内的敌人
        {
            QList<Enemy * > enemyList=myGame->getEnemyList();
            foreach(Enemy * enemy,enemyList)
                if(collisionWithCircle(myPos,myAttackRange,enemy->getPos(),1))
                {
                    chooseEnemyFromAttack(enemy);
                    break;
                }
        }
}
Enemy * Tower::getAttackedEnemy()
{
    return myChooseEnemy;
}
void Tower::getRemoved()
{
    if(getAttackedEnemy())//这里要判断是不是空指针NULL
    {
        getAttackedEnemy()->getLostSight(this);
    }
    myGame->removeTower(this);
}

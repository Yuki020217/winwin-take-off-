#ifndef TOWERPOSITION_H
#define TOWERPOSITION_H


#include <QPainter>
#include <QString>
#include <QPixmap>

class TowerPosition
{
public:
    TowerPosition(QPoint pos,const QPixmap & sprite =QPixmap(":/pics/open_spot.png"));//图片的路径
    QPoint getCenterPos();//得到防御塔坑的中心点
    QPoint getPos();//得到防御塔坑的左上点

    bool ContainPos(QPoint pos);//判断pos点是否在防御塔坑的范围内

    void draw(QPainter * painter) const;

    void setHasTower(bool hasTower);//设置是否有防御塔
    bool hasTower();//判断该防御塔坑内有没有防御塔

 private:
    QPoint myPos;
    QPixmap mySprite;

    bool myHasTower;
    static const QSize myFixedSize;//防御塔坑的固定大小
};


#endif // TOWERPOSITION_H

#include "bullet.h"
#include "tower.h"
#include "mainwindow.h"
#include "utility.h"
#include "enemy.h"

#include <QPoint>
#include <QPainter>
#include <QString>
#include <QPropertyAnimation>

const QSize Bullet::myFixedSize(8,8);

Bullet::Bullet()
{
}

Bullet::Bullet(QPoint startPos,QPoint targetPos,int damage,Enemy * targetEnemy,MyWindow * game,QString path):
    myStartPos(startPos),
    myTargetPos(targetPos),
    myDamage(damage),
    myPath(path),
    myTargetEnemy(targetEnemy),
    myGame(game)
{
}

QPoint Bullet::getCurrentPos()
{
    return myCurrentPos;
}

void Bullet::setCurrentPos(QPoint pos)
{
    myCurrentPos=pos;
}

void Bullet::move()
{
    static int duration=100;//子弹飞行的时间，经过100ms击中敌人
    QPropertyAnimation * animation=new QPropertyAnimation(this,"myCurrentPos");
    animation->setDuration(duration);//设置持续时间
    animation->setStartValue(myStartPos);//设置起始位置
    animation->setEndValue(myTargetPos);//设置目标位置
    connect(animation,SIGNAL(finished()),this,SLOT(hitTarget()));//连接信号槽，击中敌人后，子弹动态运动结束
    animation->start();
}

void Bullet::hitTarget()
{
    if(myGame->getEnemyList().indexOf(myTargetEnemy)!=-1)//如果mywindow的敌人列表中，有子弹击中的这个敌人，该敌人受到相应的伤害
       myTargetEnemy->getDamaged(myDamage);
    myGame->removeBullet(this);//击中敌人后子弹就要消失
}

void Bullet::draw(QPainter *painter) const
{
    painter->drawPixmap(myCurrentPos,myPath);
}

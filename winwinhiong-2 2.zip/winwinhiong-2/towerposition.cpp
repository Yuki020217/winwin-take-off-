#include "towerposition.h"

#include <QSize>
#include <QPainter>
#include <QPixmap>

const QSize TowerPosition::myFixedSize(35,35);//设置图片的大小

TowerPosition::TowerPosition(QPoint pos,const QPixmap & sprite):
    myPos(pos),
    mySprite(sprite),
    myHasTower(false)
{
}

bool TowerPosition::hasTower()
{
    return myHasTower;
}

void TowerPosition::setHasTower(bool hasTower)
{
    myHasTower=hasTower;
}
QPoint TowerPosition::getCenterPos()
{
    QPoint tmp;
    tmp.setX(myPos.x()+myFixedSize.width()/2);
    tmp.setY(myPos.y()+myFixedSize.height()/2);
    return tmp;
}

QPoint TowerPosition::getPos()
{
    return myPos;
}

bool TowerPosition::ContainPos(QPoint pos)
{
    bool xInHere=pos.x()>myPos.x() && pos.x()<myPos.x()+myFixedSize.width();
    bool yInHere=pos.y()>myPos.y() && pos.y()<myPos.y()+myFixedSize.height();
    return xInHere && yInHere;
}
void TowerPosition::draw(QPainter *painter) const
{
    painter->drawPixmap(myPos.x(),myPos.y(),mySprite);
}

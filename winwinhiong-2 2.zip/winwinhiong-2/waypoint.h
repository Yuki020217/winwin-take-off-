#ifndef WAYPOINT_H
#define WAYPOINT_H

#include <QPoint>
#include <QPainter>

class wayPoint
{
public:
    wayPoint(QPoint pos);
    void setNextWayPoint(wayPoint * nextWayPoint);
    wayPoint * getNextWayPoint();
    const QPoint getPos();
    void draw(QPainter * poainter)const;
private:
    QPoint myPos;
    wayPoint * myNextWayPoint;
};

#endif // WAYPOINT_H

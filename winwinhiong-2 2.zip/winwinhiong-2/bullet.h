#ifndef BULLET_H
#define BULLET_H

#include <QObject>
#include <QPoint>
#include <QPainter>
#include <QString>
#include <QSize>

#include "enemy.h"
#include "tower.h"
#include "mainwindow.h"

class Enemy;
class MainWindow;
class Tower;

class Bullet :public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint myCurrentPos READ getCurrentPos WRITE setCurrentPos)//子弹动态移动
public:
    Bullet();
    Bullet(QPoint startPos,QPoint targetPos,int damage,Enemy * targetEnemy,MyWindow * game,QString path=":/pics/bullet.png");
    QPoint getCurrentPos();//得到子弹的当前位置
    void setCurrentPos(QPoint pos);//设置子弹的当前位置

    void move();//子弹的移动
    void draw(QPainter * painter)const;//绘画子弹

private slots:
    void hitTarget();//私有信号槽，击中敌人的时候触发

private:
    QPoint myStartPos;
    QPoint myTargetPos;
    QPoint myCurrentPos;
    int myDamage;
    QString myPath;

    Enemy * myTargetEnemy;
    MyWindow * myGame;

    static const QSize myFixedSize;
};

#endif // BULLET_H

#include "enemy.h"
#include "mainwindow.h"
#include "tower.h"
#include "utility.h"
#include "waypoint.h"

#include <QPainter>
#include <QPoint>
#include <QSize>
#include <QString>
#include <QVector2D>
#include <QPixmap>

const QSize Enemy::myFixedSize(35,35);//

Enemy::Enemy(wayPoint * startWayPoint,MyWindow *game,QString path):
    QObject(0),
    myGame(game),
    myPos(startWayPoint->getPos()),
    myPath(path)
{
    myMaxHp=40;
    myCurrentHp=myMaxHp;
    myWalkingSpeed=1;
    myActive=false;
    myDestinationWayPoint=startWayPoint->getNextWayPoint();//直接从当前航点得到下一个航点
}

Enemy::~Enemy()
{
    attackerTower_list.clear();//清楚在攻击该敌人的防御塔
    myDestinationWayPoint=NULL;//全部设为空指针
    myGame=NULL;
}

void Enemy::draw(QPainter *painter) const
{
    if(!myActive)//如果敌人不能移动，就不对它进行绘画
    {
        return ;
    }painter->save();
    //下面准备绘画敌人的血条
    static const int healthBarWidth=myFixedSize.width();//设置血条的长度
    QPoint healthBarPoint=myPos+QPoint(-myFixedSize.width()/2,-myFixedSize.height());//设置血条的左上点
    painter->setPen(Qt::NoPen);//画笔的颜色
    painter->setBrush(Qt::red);//刷子的颜色，用来填充内部
    QRect healthBarBackRect(healthBarPoint,QSize(healthBarWidth,2));
    painter->drawRect(healthBarBackRect);//画出血条

    //由于敌人被攻击后会扣血，因此还要画一个显示敌人当前血量的柱形
    painter->setBrush(Qt::green);
    QRect healthBarRect(healthBarPoint,QSize((double)myCurrentHp/myMaxHp*healthBarWidth,2));
    painter->drawRect(healthBarRect);//画出当前血量血条

    //把敌人画出来
    QPoint tmp(myPos.x()-myFixedSize.width()/2,myPos.y()-myFixedSize.height()/2);//得到图片的左上点
    painter->drawPixmap(tmp.x(),tmp.y(),myPath);
    painter->restore();
}

void Enemy::move()
{
    if(!myActive)//如果不能移动，就直接return
    {
        return ;
    }
    if(collisionWithCircle(myPos,1,myDestinationWayPoint->getPos(),1))//如果到达了目标航点
    {
        if(myDestinationWayPoint->getNextWayPoint())//如果还存在下一个航点
        {//重新设置敌人的位置，和目标航点
            myPos=myDestinationWayPoint->getPos();
            myDestinationWayPoint=myDestinationWayPoint->getNextWayPoint();
        }
        else//如果没有下一个航点了，代表敌人已经到达了基地
        {
            myGame->getHpDamaged();
            myGame->removeEnemy(this);
            return ;
        }
    }
    else//如果还在去目标航点的路上
    {//采用QVectoer2D中的两点移动方法
        QPoint targetPoint=myDestinationWayPoint->getPos();
        double movementSpeed=myWalkingSpeed;
        QVector2D normailzed(targetPoint-myPos);
        normailzed.normalize();
        myPos=myPos+normailzed.toPoint()*movementSpeed;
    }
}

void Enemy::doActive()
{
    myActive=true;
}

QPoint Enemy::getPos()
{
    return myPos;
}

void Enemy::getAttacked(Tower *tower)
{
    attackerTower_list.push_back(tower);
}

void Enemy::getDamaged(int damage)
{
    myCurrentHp-=damage;
    if(myCurrentHp<=0)
    {
        myGame->awardGlod();
        getRemoved();
    }
}

void Enemy::getRemoved()
{
    if(attackerTower_list.empty())
    {
        return ;
    }
    else
    {
        myGame->removeEnemy(this);
    }
    foreach(Tower * tower,attackerTower_list)
                tower->targetKilled();

}
void Enemy::getLostSight(Tower *tower)
{
    attackerTower_list.removeOne(tower);
}

void Enemy::reSetHp(int maxHp)
{
    myMaxHp=maxHp;
    myCurrentHp=maxHp;
}


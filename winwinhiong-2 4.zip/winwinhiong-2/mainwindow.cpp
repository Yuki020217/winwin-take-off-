#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPixmap>
#include <QPaintEvent>
#include <QPushButton>
#include "mywindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->setFixedSize(600,800);
    ui->setupUi(this);
    QPushButton * btn =new QPushButton(this);
    btn->setFixedSize(100,800);
    btn->move(500,0);
    btn->setFlat(true);
    btn->setStyleSheet("background-color: rgba(0,0,0,0)");
    MyWindow * scene = new MyWindow;
    connect(btn,&QPushButton::clicked,this,[=](){
        this->close();
        scene->show();
    });
    connect(scene,&MyWindow::chooseBack,this,[=](){
        scene->close();
        this->show();
    });
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::paintEvent(QPaintEvent *){
    QPainter painter(this);
    QPixmap pixmap(":/pics/winwintakeoff.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

}

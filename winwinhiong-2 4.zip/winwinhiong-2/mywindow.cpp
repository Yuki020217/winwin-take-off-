#include "mywindow.h"
#include "mybutton.h"
#include "waypoint.h"
#include "towerposition.h"
#include "tower.h"
#include "enemy.h"
#include <QPainter>
#include <QPixmap>
#include <QTimer>
#include <QPoint>
#include <QMouseEvent>




MyWindow::MyWindow(QWidget *parent) :
    QMainWindow(parent),
    myPlayerHp(5),
    myPlayerGlod(1000),
    myWaves(0),
    myGameWin(false),
    myGameLose(false)

{
    this->setFixedSize(600,800);
    addWayPoint1();
    loadTowerPosition1();
    MyButton * back_btn = new MyButton(":/pics/back.png");
    back_btn->setParent(this);
    back_btn->move(0,120);
    connect(back_btn,&MyButton::clicked,this,[=](){
        emit chooseBack();
    });
    QTimer * timer=new QTimer(this);
    connect(timer,SIGNAL(timeout()),this,SLOT(updateMap()));
    timer->start(30);
    QTimer::singleShot(300,this,SLOT(gameStart()));
}
void MyWindow::paintEvent(QPaintEvent *){
    if(myGameLose || myGameWin)//画出游戏结束的画面
        {
            QString text=myGameLose ? "YOU LOST":"YOU WIN";
            QPainter painter(this);
            painter.setPen(Qt::red);
            painter.drawText(rect(),Qt::AlignCenter,text);
            return ;
        }
    QPainter painter(this);
    QString path(":/pics/background.jpg");
    painter.drawPixmap(0,0,this->width(),this->height(),path);
    foreach (MyObject * object,object_list)
        object->draw(&painter);
    foreach(const wayPoint * waypoint,wayPoint_list)
        waypoint->draw(&painter);
    foreach(const TowerPosition & towerposition,towerPosition_list)
        towerposition.draw(&painter);
    foreach(const Tower * tower,tower_list)
        tower->draw(&painter);
    foreach(const Enemy * enemy,enemy_list)
        enemy->draw(&painter);
    foreach(const Bullet * bullet,bullet_list)
        bullet->draw(&painter);

    drawHp(&painter);
    drawGlod(&painter);
    drawWaves(&painter);



}

\


void MyWindow::addWayPoint1(){
    wayPoint * waypoint1=new wayPoint(QPoint(240,100));
        wayPoint_list.push_back(waypoint1);

        wayPoint * waypoint2=new wayPoint(QPoint(240,200));
        waypoint1->setNextWayPoint(waypoint2);
        wayPoint_list.push_back(waypoint2);

        wayPoint * waypoint3=new wayPoint(QPoint(240,300));
        waypoint2->setNextWayPoint(waypoint3);
        wayPoint_list.push_back(waypoint3);

        wayPoint * waypoint4=new wayPoint(QPoint(240,400));
        waypoint3->setNextWayPoint(waypoint4);
        wayPoint_list.push_back(waypoint4);

        wayPoint * waypoint5=new wayPoint(QPoint(240,500));
        waypoint4->setNextWayPoint(waypoint5);
        wayPoint_list.push_back(waypoint5);

        wayPoint * waypoint6=new wayPoint(QPoint(240,600));
        waypoint5->setNextWayPoint(waypoint6);
        wayPoint_list.push_back(waypoint6);

        wayPoint * waypoint7=new wayPoint(QPoint(240,700));
        waypoint6->setNextWayPoint(waypoint7);
        wayPoint_list.push_back(waypoint7);

}

void MyWindow::loadTowerPosition1()
{
    QPoint pos[]=
    {
        QPoint(280,150),
        QPoint(280,250),
        QPoint(280,350),
        QPoint(280,450),
        QPoint(280,550),
        QPoint(280,650),

    };
    int len=sizeof(pos)/sizeof(pos[0]);
    for(int i=0;i<len;i++)
    {
        towerPosition_list.push_back(pos[i]);
    }
}
void MyWindow::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos=event->pos();//得到鼠标点击的位置
    auto it=towerPosition_list.begin();
    while(it!=towerPosition_list.end())//遍历所有的防御塔坑
    {
        if(Qt::LeftButton==event->button())//如果是鼠标左键点击
        {
            if(it->ContainPos(pressPos) && !it->hasTower() && canBuyTower())//如果鼠标点击的位置在防御塔坑的范围内
            {
                Tower * tower=new Tower(it->getCenterPos(),this);//创建一个新的防御塔
                myPlayerGlod-=300;
                tower_list.push_back(tower);//把这个防御塔放到储存防御塔的list中
                it->setHasTower(true);
                update();//更新地图
                break;//进行了一次操作，可以直接退出循环了
            }
        }
            ++it;

    }
}
void MyWindow::getHpDamaged()
{
    myPlayerHp-=1;//敌人进入基地，扣一滴血
}

void MyWindow::awardGlod()
{
    myPlayerGlod+=200;//杀死一个敌人，奖励200，制作者可以自由更改数值
}

void MyWindow::removeEnemy(Enemy *enemy)
{
    Q_ASSERT(enemy);
    enemy_list.removeOne(enemy);//死亡的敌人从enemylist中移除
    delete enemy;
    if(enemy_list.empty())
        {
            ++myWaves;
            if(!loadWaves())
            {
                myGameWin=true;
            }
        }
}

QList<Enemy *> MyWindow::getEnemyList()
{
    return enemy_list;
}
bool MyWindow::loadWaves()
{
    if(myWaves>=6)
    {
        return false;
    }
    int enemyStartInterval[]={100,500,600,1000,3000,6000};//敌人出现的时间
    for(int i=0;i<6;++i)
    {
        wayPoint * startWayPoint;
        startWayPoint=wayPoint_list.first();
        Enemy * enemy=new Enemy(startWayPoint,this);//创建一个新得enemy
        enemy_list.push_back(enemy);
        QTimer::singleShot(enemyStartInterval[i],enemy,SLOT(doActive()));
    }
    return true;
}

void MyWindow::gameStart()
{
    loadWaves();
}
void MyWindow::updateMap()
{
    foreach(Enemy * enemy,enemy_list)
        enemy->move();
    update();
    foreach(Tower * tower,tower_list)
    tower->checkEnemyInRange();
}
void MyWindow::doGameOver()
{
    if(!myGameLose)
    {
        myGameLose=true;
    }
}

bool MyWindow::canBuyTower()
{
    if(myPlayerGlod>=300)
    {
        return true;
    }
    return false;
}

void MyWindow::drawWaves(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(500,5,100,25),QString("WAVES: %1").arg(myWaves+1));
    painter->restore();
}
void MyWindow::drawHp(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(30,5,100,25),QString("HP: %1").arg(myPlayerHp));
    painter->restore();
}

void MyWindow::drawGlod(QPainter *painter) const
{
    painter->save();
    painter->setPen(Qt::red);
    painter->drawText(QRect(300,5,100,25),QString("GOLD: %1").arg(myPlayerGlod));
}

void MyWindow::removeBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    bullet_list.removeOne(bullet);

}
void MyWindow::addBullet(Bullet *bullet)
{
    Q_ASSERT(bullet);
    bullet_list.push_back(bullet);
}


#ifndef ENEMY_H
#define ENEMY_H

#include <QObject>
#include <QString>
#include <QPainter>
#include <QSize>
#include <QPixmap>
#include "waypoint.h"
#include "mywindow.h"
#include "tower.h"

class MyWindow;
class Tower;
class QPainter;
class wayPoint;

class Enemy:public QObject
{
    Q_OBJECT
public:
    Enemy(wayPoint * startPoint, MyWindow * game,QString path=":/pics/cherrybomb.png");
    ~Enemy();
    void draw(QPainter * painter)const;
    void move();//敌人的移动

    QPoint getPos();//得到敌人的当前位置

    void getAttacked(Tower * tower);//被tower攻击
    void getDamaged(int damage);//敌人被攻击受到伤害
    void getRemoved();//当血量非正时，敌人死亡，需要移除
    void getLostSight(Tower * tower);//敌人脱离tower的攻击范围
    void reSetHp(int maxHp);

private slots:
    void doActive();//私有信号槽，敌人是否可以移动

private:
    int myMaxHp;//最大血量
    int myCurrentHp;//当前血量
    int myWalkingSpeed;//移动速度
    bool myActive;//是否可以移动

    wayPoint * myDestinationWayPoint;//目标航点的指针
    MyWindow * myGame;//mywindow的指针
    QPoint myPos;//当前位置
    QString myPath;//图片路径
    QList<Tower *> attackerTower_list;//正在攻击该敌人的防御塔list
    static const QSize myFixedSize;
};
#endif // ENEMY_H

#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include "tower.h"
#include <QList>
#include "myobject.h"
#include <QToolButton>
#include "waypoint.h"
#include "towerposition.h"
#include <QMouseEvent>
#include "enemy.h"
#include "bullet.h"

class wayPoint;
class Tower;
class Enemy;
class Bullet;

static const int tower1Cost=300;//第一种塔的价钱
static const int tower2Cost=400;//第二种

class MyWindow : public QMainWindow
{
    Q_OBJECT

public:
    void paintEvent(QPaintEvent *);
    explicit MyWindow(QWidget *parent = nullptr);
    void addMyObject();
    void addWayPoint1();
    void loadTowerPosition1();
    void getHpDamaged();//敌人进入基地内部，基地要扣血
    void awardGlod();//敌人死亡，奖励金钱
    void removeEnemy(Enemy * enemy);//敌人死亡，在mainwindow中要移除
    QList<Enemy *> getEnemyList();//得到Enemy*的list
    bool loadWaves();//加载敌人的函数
    void removeBullet(Bullet * bullet);
    void addBullet(Bullet * bullet);
    void drawHp(QPainter * painter)const;//画出当前基地血量的信息
    void drawGlod(QPainter * painter)const;//画出当前玩家金钱的信息
    void drawWaves(QPainter * painter)const;//画出当前的波数信息
    bool canBuyTower();

    void doGameOver();//执行游戏结束


protected:
    void mousePressEvent(QMouseEvent *);

private:
    QList<MyObject*> object_list;
    QList<wayPoint*> wayPoint_list;
    QList<TowerPosition> towerPosition_list;
    QList<Tower*> tower_list;
    QList<Enemy *> enemy_list;
    int myPlayerHp;//基地的血量
    int myPlayerGlod;//初始金钱
    int myWaves;//波数
    bool myGameWin;
    bool myGameLose;
    QList<Bullet *> bullet_list;

signals:
    void chooseBack();
private slots:
    void updateMap();
    void gameStart();


};

#endif // MYWINDOW_H
